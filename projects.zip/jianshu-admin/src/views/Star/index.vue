<template>
  <div>
      点赞管理
  </div>
</template>

<script>
export default {

}
</script>

<style>

</style>